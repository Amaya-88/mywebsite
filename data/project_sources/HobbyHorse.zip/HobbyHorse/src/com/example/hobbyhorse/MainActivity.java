package com.example.hobbyhorse;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
//import android.view.Menu;
//import android.view.MenuItem;

public class MainActivity extends Activity implements SensorEventListener {
	private SensorManager senSensorManager;
	private Sensor senAccelerometer;
	
	private long lastUpdate = 0;
	private long lastTriggerSound = 0;
	//private float last_x, last_y, last_z;
	//private static final int SHAKE_THRESHOLD = 600;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		 senSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		 senAccelerometer = senSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		 senSensorManager.registerListener(this, senAccelerometer , SensorManager.SENSOR_DELAY_NORMAL);
	}

	@Override
	public void onAccuracyChanged(Sensor arg0, int arg1) {
	
	}

	@Override
	public void onSensorChanged(SensorEvent sensorEvent) {
	    Sensor mySensor = sensorEvent.sensor;
	    
	    if (mySensor.getType() == Sensor.TYPE_ACCELEROMETER) {
	        float x = sensorEvent.values[0];
	        float y = sensorEvent.values[1];
	        float z = sensorEvent.values[2];
	        
	        long curTime = System.currentTimeMillis();

            
            //System.out.println("acc x: "+x);
            //System.out.println("acc y: "+y + " acc z: "+z);
            //System.out.println("acc z: "+z);
            if(y > 3) {
            	if((curTime - lastTriggerSound) > 3000){
	            	System.out.println("trigger sound");
	            	EffectsPlayer.playSound(this, R.raw.horse_whinny);
	            	lastTriggerSound = curTime;
            	}
            	

            }
	        
	    }			
	}
}
